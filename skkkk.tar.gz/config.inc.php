<?php
$conf['database']['user'] = 'root';
$conf['database']['password'] = 'tumko34h1se';
$conf['database']['host'] = '146.0.237.17';
$conf['database']['database'] = 'myphonesystem';
$conf['astman']['user'] = 'cron';
$conf['astman']['password'] = '1234';
$conf['dirs']['moh'] = '/data/moh';
$conf['dirs']['monitor'] = '/data/monitor';
$conf['dirs']['agi'] = dirname(__FILE__) . '/../agi';
?>

